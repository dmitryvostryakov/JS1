/* 3. Нарисовать горку с помощью console.log (используя цикл for), как показано на рисунке,
только у вашей горки должно быть 20 рядов, а не 5:
x
xx
xxx
xxxx
xxxxx */
/**
 * @param  {} letn="x";n.length<=20;n+="x"
 * @param  {} {console.log(n
 */
for (let n = "x"; n.length <= 20; n += "x") {
    console.log(n);
}